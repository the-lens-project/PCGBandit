# FreeMHD examples

Example cases adapted from [FreeMHD](https://github.com/PlasmaControl/FreeMHD) to work with OpenFOAM-v2506.
To run, first compile the custom FreeMHD solver `epotMultiRegionInterFoam`: `wmake solvers/epotMultiRegionInterFoam`.
Then inside either case directory (`closedPipe` or `fringingBField`) you can do the following:

1. to run a simulation do `./Allrun`; the main log file is `log.epotMultiRegionInterFoam`
2. to read the main log file open `log.epotMultiRegionInterFoam`
3. to modify the linear solvers edit any of the `fvSolution` files in the directories `system/insulator`, `system/liquid`, or `system/solidWalls`
4. to clean up a simulation do `./Allclean`
